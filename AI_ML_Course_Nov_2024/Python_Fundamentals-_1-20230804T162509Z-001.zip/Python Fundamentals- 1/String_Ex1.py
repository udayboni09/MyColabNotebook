
str = "abcdac"

substr = "xda"

print(str.find(substr)) #



# .join() with lists
numList = ['1', '2', '3', '4']

print(' | '.join(numList)) # "1 | 2 | 3, 4"


cars = "BMW-Telsa-Range Rover"

# split at '-'
print(cars.split("-"))


words = "cats dogs lions"
print(words.split())