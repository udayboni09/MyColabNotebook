# Examples of Arithmetic Operator
a = 9
b = 4

print(9/4) # 2.25

print(9//4) # 2

print(type(a))

add = a + b

sub = a - b

mul = a * b

div1 = a / b # 2.25

div2 = a // b # 2

mod = a % b

# Power
p = a ** b

# print results
print(add)
print(sub)
print(mul)
print(div1)
print(div2)
print(mod)
print(p)
