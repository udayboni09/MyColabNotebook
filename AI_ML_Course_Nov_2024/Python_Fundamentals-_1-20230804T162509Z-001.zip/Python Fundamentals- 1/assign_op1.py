# Examples of Assignment Operators
a = 10

# Assign value
b = a
print(b)

# Add and assign value

b = b + 10 # 20

b += 10 # b = b + 10 --> 30

print(b)

# Subtract and assign value
b -= a # b = b - a
print(b)

# multiply and assign
b *= a
print(b)

