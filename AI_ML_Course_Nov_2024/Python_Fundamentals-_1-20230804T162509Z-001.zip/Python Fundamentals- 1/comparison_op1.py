# Examples of Relational Operators
a = 13
b = 20

# a > b is False

x = a > b # False

print(x)

# a < b is True
print(a < b)

# a == b is False
print(a == b)

# a != b is True
print(a != b)

# a >= b is False
print(a >= b)

# a <= b is True
print(a <= b)
