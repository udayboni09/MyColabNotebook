
def add(a, b):  # argument
    return a + b


c = add(4, 8) # parameter
print(c)

