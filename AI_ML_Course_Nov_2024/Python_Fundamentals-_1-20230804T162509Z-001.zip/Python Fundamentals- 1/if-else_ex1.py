# odd or even

a = 13

if 10 % 2 == 0:
    print("Even")
    print("Do Something")


else:
    print("Odd")

