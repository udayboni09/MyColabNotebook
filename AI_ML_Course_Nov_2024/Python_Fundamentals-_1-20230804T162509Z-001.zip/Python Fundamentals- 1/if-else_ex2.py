# python program to illustrate If statement



number = 7

if number > 0:
   print("Positive number")
   print("Inside if block")

elif number < 0:            #else if == elif
    print("-ve number")
    print("Inside if else")

else:
    print("Zero")
    print("Inside else")


print("outside if")



