name = input("Enter your name ")
year_of_birth = input("Enter your Year of birth ")

year_of_birth = int(year_of_birth)

age = 2023 - year_of_birth

print(name)
print(age)