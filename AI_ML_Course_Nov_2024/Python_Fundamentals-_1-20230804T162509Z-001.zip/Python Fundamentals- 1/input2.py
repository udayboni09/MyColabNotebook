
num1 = int(input("Enter first number "))

num2 = int(input("Enter second number "))

#num1 = int(num1) # "10" - 10
#num2 = int(num2)

sum = num1 + num2  # "10" + "20" = "1020"

print(sum)