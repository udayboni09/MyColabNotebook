
list1 = [1, 5, 3, 4, 10]  # dynamic Array, vector, Arraylist  , n = 5

for x in list1:
    print(x)


for i in range(0, len(list1)):
    print(list1[i])