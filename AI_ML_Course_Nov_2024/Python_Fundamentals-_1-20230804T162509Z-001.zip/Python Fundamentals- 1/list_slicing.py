# https://www.programiz.com/python-programming/examples/list-slicing

Lst = [50, 70, 30, 20, 90, 10, 50]

# Display list
print(Lst[1:5]) # from index 1 till index 4

# Initialize list
List = [1, 2, 3, 4, 5, 6, 7, 8, 9]

# Show original list
print("\nOriginal List:\n", List)

print("\nSliced Lists: ")

# Display sliced list
print(List[3:9:2])

# Display sliced list
print(List[::2])

print(List[::])

# String slicing
String = 'CodingIsFun'

# Using indexing sequence
print(String[1:5])
