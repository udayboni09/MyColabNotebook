
# Logical Operators - this is not code

a = True
b = False

c = a or b # ||
d = a and b  # &


print(c)
print(d)
