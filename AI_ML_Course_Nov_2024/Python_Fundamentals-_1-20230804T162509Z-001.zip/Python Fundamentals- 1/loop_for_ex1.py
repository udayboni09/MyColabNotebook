

for i in range(10): # for (int i=0; i<10; i++)
    print("Hello world")
    #print(i)


for i in range(10, 20): # for (i=10; i<20; i++)
    print(i)



for i in range(1, 20, 2): # for (i=1; i<20; i = i+2)
    print(i)

sum = 0

for x in range(1, 101):
    sum = sum + x


message = ""

for x in range(1, 10):
    message = message + str(x)
    print(message)


