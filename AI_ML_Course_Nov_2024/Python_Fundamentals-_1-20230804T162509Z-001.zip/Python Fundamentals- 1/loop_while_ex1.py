


count = 1

while count <= 5:
    print("Hello")
    count = count + 1  # 2

print(count)

sum = 0

i = 1
n = 20

while i <= n:
    print("i: ", i)
    print("Sum ", sum)
    sum = sum + i # sum = sum + 1
    i = i + 1

print(i)
print(sum)


a = 5

a += 1 # a  = a +1
print(a)


