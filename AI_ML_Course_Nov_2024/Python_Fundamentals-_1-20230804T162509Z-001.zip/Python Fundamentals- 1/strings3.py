message = 'Python is fun'

print(message.startswith('Python'))

cars = 'BMW-Telsa-Range Rover'

# split at '-'
print(cars.split('-'))

text= 'Love thy neighbor'

# splits at space
print(text.split())

grocery = 'Milk, Chicken, Bread'

# splits at ','
print(grocery.split(', '))

# Splits at ':'
print(grocery.split(':'))