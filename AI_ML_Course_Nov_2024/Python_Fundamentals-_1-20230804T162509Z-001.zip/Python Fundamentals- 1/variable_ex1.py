
# variable and Data Types

'''
Multiline comments
'''

name = "Matt"

age = 30

is_married = True

cgpa = 3.7

print(type(name))
print(type(age))

print(age)
print(name)

age = "xyz"

print(type(age))
print(age)

a = 5

a = "Hello world"

a = True

print(a)

a = 1000000000000000000000000000000000

print(a)